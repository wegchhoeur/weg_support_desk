<?php

return array (
  'title' => 'Get in touch with us!!!',
  'button' => 'Submit a Message',
  'banner_title' => 'No luck what you\'re looking for?',
  'banner_subtitle' => 'Let us know details about your quesiton. We\'ll get back to you!',
  'banner_button' => 'Contact with Us',
);
