<?php

return array (
  'home' => 'Home',
  'article' => 'Knowledge Base',
  'faqs' => 'FAQs',
  'videos' => 'Videos',
  'contact' => 'Contact Us',
  'search' => 'Search',
);
