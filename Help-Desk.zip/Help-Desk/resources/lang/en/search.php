<?php

return array (
  'title' => 'How can we help you?',
  'placeholder' => 'Ask a question or search by keyword...',
  'result_title' => 'Search results for:',
  'no_result' => 'No Result Found',
);
